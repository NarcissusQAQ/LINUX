#ifndef _TOUCH_H
#define _TOUCH_H 


int click_panduan(int x, int y, int width, int height);

int touch_panduan();
int direction_panduan();

#endif
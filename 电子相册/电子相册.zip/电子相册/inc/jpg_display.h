#include <stdio.h>
#include <stdlib.h>
#include "jpeglib.h"
#include "lcd.h"

int jpg_display(char*jpg_name);
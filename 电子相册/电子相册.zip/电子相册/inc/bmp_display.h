#ifndef _BMP_DISPLAY_H_
#define _BMP_DISPLAY_H_

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

int bmp_display(char *s);

#endif